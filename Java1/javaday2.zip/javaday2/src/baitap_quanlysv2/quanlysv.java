/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baitap_quanlysv2;

import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;
/**
 *
 * @author nguyenthuyduong
 */
public class quanlysv {
    public static void main(String[] args) {
        
        //khoi tao mang doi tuong
        students[] arrsv = new students[30];
        int n;
        //Khoi tao 30 sinh vien
        for(int i=0;i<arrsv.length;i++)
        {
            arrsv[i] = new students();
        }
        do{
            Scanner sc = new Scanner(System.in);
            //Nhap so luong sinh vien (N)
            System.out.println("Nhap so luong sinh vien");
            n = sc.nextInt();
        }
        while(n<2 || n>30);
        
        //Ham nhap cho phep nhap N sinh vien va thong tin N sinh vien
        for(int i=0; i<n; i++)
        {
            System.out.println("Sinh vien thu" + i + ":");
            arrsv[i].Nhaptt();
        }
        //Ham hien thi thong tin N sinh vien
        for(int i=0; i<n; i++)
        {
            arrsv[i].Hient();
        }
        //Sort sinh vien theo diem so
        Arrays.sort(arrsv, Comparator.comparing(students::getDiemso));
        
    }
}
